package org.kidoni.logdb;

record RecordHeader(byte type, int length) {
}
