package adt;

public class LruCacheEvictionStrategy<E> implements CacheEvictionStrategy<E> {
    @Override
    public E evict() {
        return null;
    }
}
