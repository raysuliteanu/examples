package adt;

public class AbstractLinkNode<E> {
    protected E value;
}
