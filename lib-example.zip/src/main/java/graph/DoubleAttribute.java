package graph;

public class DoubleAttribute extends Attribute<Double> {
    public DoubleAttribute(final String name, final Double value) {
        super(name, value);
    }
}
