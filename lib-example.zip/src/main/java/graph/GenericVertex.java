package graph;

public class GenericVertex<T> extends AbstractVertex<T> {
    public GenericVertex(final int number) {
        super(number);
    }
}
