package graph;

public interface ValueVertex<T> extends Vertex<T> {
    T value();
}
