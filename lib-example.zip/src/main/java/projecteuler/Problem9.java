package projecteuler;

public class Problem9 {
    public static void main(String[] args) {

    }
}
